export default function Reports() {
  return (
    <h1 className="text-3xl font-bold text-indigo-600">Reports</h1>
  );
}
