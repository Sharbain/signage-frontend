export default function Settings() {
  return (
    <h1 className="text-3xl font-bold text-indigo-600">Settings</h1>
  );
}
