// client/src/lib/api.ts

const API_BASE = import.meta.env.VITE_API_BASE_URL || "/api";

// Helper to automatically attach JWT
async function authorizedFetch(url: string, options: any = {}) {
  const token = localStorage.getItem("accessToken");

  const headers = {
    ...(options.headers || {}),
    "Content-Type": options.body ? "application/json" : undefined,
    "Authorization": token ? `Bearer ${token}` : undefined,
  };

  return fetch(url, {
    ...options,
    headers,
  });
}

export const api = {
  auth: {
    register: async (data: any) =>
      authorizedFetch(`${API_BASE}/auth/register`, {
        method: "POST",
        body: JSON.stringify(data),
      }),

    login: async (data: any) =>
      authorizedFetch(`${API_BASE}/auth/login`, {
        method: "POST",
        body: JSON.stringify(data),
      }).then(async (res) => {
        const json = await res.json();

        // Save JWT after login
        if (json.accessToken) {
          localStorage.setItem("accessToken", json.accessToken);
        }

        return json;
      }),
  },

  screens: {
    getAll: async () =>
      authorizedFetch(`${API_BASE}/screens`, { method: "GET" }),

    getOne: async (id: string) =>
      authorizedFetch(`${API_BASE}/screens/${id}`, { method: "GET" }),

    create: async (data: any) =>
      authorizedFetch(`${API_BASE}/screens`, {
        method: "POST",
        body: JSON.stringify(data),
      }),

    update: async (id: string, data: any) =>
      authorizedFetch(`${API_BASE}/screens/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }),

    delete: async (id: string) =>
      authorizedFetch(`${API_BASE}/screens/${id}`, {
        method: "DELETE",
      }),
  },

  media: {
    getAll: async () =>
      authorizedFetch(`${API_BASE}/media`, { method: "GET" }),

    create: async (data: any) =>
      authorizedFetch(`${API_BASE}/media`, {
        method: "POST",
        body: JSON.stringify(data),
      }),

    delete: async (id: string) =>
      authorizedFetch(`${API_BASE}/media/${id}`, {
        method: "DELETE",
      }),
  },

  devices: {
    list: async () =>
      authorizedFetch(`${API_BASE}/devices/list`, { method: "GET" }),

    listFull: async () =>
      authorizedFetch(`${API_BASE}/devices/list-full`, { method: "GET" }),

    details: async (id: string) =>
      authorizedFetch(`${API_BASE}/devices/${id}/details`, {
        method: "GET",
      }),

    locationList: async () =>
      authorizedFetch(`${API_BASE}/devices/locations`, {
        method: "GET",
      }),

    command: async (deviceId: string, data: any) =>
      authorizedFetch(`${API_BASE}/device/${deviceId}/command`, {
        method: "POST",
        body: JSON.stringify(data),
      }),
  },
};
